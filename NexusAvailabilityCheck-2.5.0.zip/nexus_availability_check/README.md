# Wabbajack Author Toolkit (Nexus Availability Check 2.5)

MO2 2.5+ tool plugin for Wabbajack list authors. Tools menu > **Wabbajack Author Toolkit**.

## Install
1. Delete the old single file `plugins/nexus_availability_check.py` (both would load under the same name).
2. Copy this whole `nexus_availability_check` folder into `<MO2>/plugins/`.
3. Restart MO2. Your v1 settings and verified-OK cache carry over.

Plugin data (cache, .meta backups, reports, collection archives) lives in
%LOCALAPPDATA%\WabbajackAuthorToolkit\<instance>, outside the MO2 folder, so a
portable instance never compiles it into a Wabbajack list.

## Tabs

**Nexus & links** - same checks as v1, with a cheaper request plan:
- One Nexus `fileInfo` call per unique archive. A download that matches an installed mod is a single entry, so it costs one call, not two.
- Mod-page calls only happen when there is no file ID, when you tick *Also confirm mod page status*, or as a one-off follow-up for a file that failed (to record whether the page is hidden/removed).
- Deleted files (category 6) are flagged; archived files (category 7) pass with a note.
- Installed mods are only checked separately when their archive is gone from downloads.

**Download matching** - no Nexus calls at all:
- Pairs each archive with installed mods by archive name (`installationFile`) or Nexus mod/file ID (`[installedFiles]`).
- *Apply flags* sets `installed=true` / `uninstalled=false` on matched `.meta` files, optionally `removed=true` (hidden), optionally clears stale `installed` flags.
- Edits only the keys it changes (keeps `@Variant` blobs and line endings), backs up every file first, and *Restore last backup* undoes a run. Restart MO2 afterwards so its Downloads tab reloads the states.
- Lists installed mods that have no archive in downloads.

**Collection import** (step 1 of collection -> MO2 -> Wabbajack):
- Paste a collection URL or slug (a /revisions/N URL pins the revision). Loads the mod list via Nexus's v2 GraphQL API; any field the API rejects is dropped and the query retried.
- *Get collection.json* downloads the collection archive (API key needed) and extracts collection.json with 7-Zip if installed; or load a collection.json yourself. That adds the curator's rules, FOMOD choice sets, bundled entries and patches.
- Mandatory mods are locked on; tick optional mods, and anything they `require` is pulled in automatically. Curator `conflicts` between selected mods are shown.
- Local column: installed / archive in downloads / missing / bundled / manual - no Nexus calls.
- *Check availability* (one call per file), *Download missing* (Premium, via MO2), *Open next download pages* (free accounts: Mod Manager Download pages in batches, MO2 catches the nxm links), *Copy manual links*, *Save selection* (input for step 2).
- **Install & build profile** (needs 7-Zip): installs every selected archive straight into its own mod folder. FOMOD archives are not launched - the plugin reads `fomod/ModuleConfig.xml`, applies the curator's recorded choices (steps, groups, options, condition flags, conditional file installs, priorities) and copies the resulting files. Plain archives are installed from their Data root: a top-level `Data` folder is used, an archive whose root *is* Data is installed as-is, and a single wrapper folder is only unwrapped when Data content is inside it. Game-root mods (Vortex type `dinput`/`enb`, a `vortex_override_instructions.json`, or archives of only exe/dll files) and SKSE-style root files go to `Root/`. Already-installed mods are reused. Long paths (beyond Windows' 260 characters) are supported; mod folder names are capped at 80 characters.
- Then writes a **new profile** (your current one is untouched): mod priority follows the curator's before/after rules, keeping each category together as long as the rules allow; category separators (a rule that pulls a mod out of its block gets a "Category (2)" separator); plugins.txt/loadorder.txt from the curator's plugin list. INIs/settings are copied from the current profile.
- **Root Builder:** mods that deploy to the game folder need Kezyma's Root Builder. The tab warns when selected mods need it and it is missing, the build confirmation and results say so, and *Install Root Builder* downloads the newest release from Kezyma's GitHub (after you confirm) into MO2's plugins folder - restart MO2 to load it. Game-root mods that ship their own Data folder keep it at the mod's top level (Root Builder ignores mods with `Root/Data`).
- **Game-folder files / engine injectors:** proxy DLLs (dxgi, d3d11, dinput8, version, winhttp…), `.asi` plugins, `*_loader.exe`, preloader DLLs and ENB/ReShade files found at an archive's top level go to `Root/` automatically - mixed archives are split. Right-click any mod in the list > *Install to game root* to force it (saved with the selection). *Move mods to Root…* does the same for mods that are already installed (game-folder files only, or the whole mod; *Move back* undoes it).
- **Programs:** after a build (or via *Add programs to MO2…*) the tab finds SKSE, BodySlide, Outfit Studio, Pandora, Nemesis, FNIS, xEdit, DynDOLOD/TexGen/xLODGen, LOOT, Synthesis, PGPatcher and the curator's tools in the installed mods. MO2 rewrites its executable list from memory while running, so the ticked ones are merged into ModOrganizer.ini by a small helper the moment MO2 closes (existing entries are kept; one whose program is missing is repointed; the ini is backed up).
- **Mark used downloads as installed** (on by default): flags every download an installed mod came from, with a backup.
- Cleans up half-installed folders from interrupted builds, and removes empty separators it created that no profile uses.
- Writes a build report (Markdown): failed/skipped mods, FOMOD installs that fell back to defaults, plugins missing or extra, overwrites no rule decides, rule cycles, curator tools.
- Not yet: curator binary patches (reported, not applied), per-file overrides.
- API key: optional, kept in memory or (opt-in) in %LOCALAPPDATA%\WabbajackAuthorToolkit - never in ModOrganizer.ini.

Original code: only the Nexus API and collection.json data formats are used; no Vortex (GPL-3.0) code.

**Wabbajack preflight** - picks the `*.compiler_settings` in the MO2 base folder matching the current profile (or Browse):
- Compiler settings: Source/Downloads vs this instance, Game vs managed game, OutputFile folder, free space, inside-Source warning, name/author/description, Version (and obsolete ModlistVersion), image existence/size/aspect, MachineUrl format, profiles exist, stale NoMatchInclude/Include/Ignore/AlwaysEnabled entries, enabled mods with no archive and no include rule, Include entries that bloat the .wabbajack.
- Root Builder: mods with game-folder files (injector DLLs, .asi, ENB) sitting in their Data root; mods with a Root folder but no Root Builder installed; mods with a Data folder inside Root/ (Root Builder ignores them). *Install Root Builder* and *Move mods to Root…* buttons.
- Instance: overwrite not empty, executables pointing outside the instance/game folder, archives without `.meta`, `.meta` without a usable source, orphan `.meta` files.
- Stock Game & Creation Club: MO2 pointed at a Stock Game folder inside the instance; Rare Curios must be the in-game Creations (lower-case `ccbgssse037-curios`) version per Wabbajack's featured-list criteria (also checks mods); paid Anniversary Creations present/enabled; SKSE DLL runtime vs game runtime.
- Online (optional): repository registered in `repositories.json` (with case check), your `modlists.json` parses, entry fields, `game`/`nsfw` consistency, `utility_list`, `force_down`, ISO dates, duplicate machineURLs, Version newer than published, readme/image/community links (Discord invites checked via Discord's API), and Wabbajack's own validation report for the published list (`reports/<repo>/<machine>/status.json`).
- Copy as Markdown / Save report (.md + .json).
